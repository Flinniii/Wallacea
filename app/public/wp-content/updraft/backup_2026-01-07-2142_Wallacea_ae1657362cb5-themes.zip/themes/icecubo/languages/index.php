<?php
// phpcs:ignore
// Silence is golden.
?>
