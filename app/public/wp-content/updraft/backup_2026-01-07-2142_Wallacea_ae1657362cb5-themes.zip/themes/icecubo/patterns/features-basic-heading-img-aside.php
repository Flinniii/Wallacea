<?php
// phpcs:ignore
/**
 * Title: Features in columns with heading and image aside.
 * Slug: icecubo/features-basic-heading-img-aside
 * Categories: icecubo-features
 */
?>
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:image {"aspectRatio":"1","scale":"cover","className":"is-style-rounded"} -->
<figure class="wp-block-image is-style-rounded"><img alt="" style="aspect-ratio:1;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size"></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cursus in hac habitasse platea dictumst quisque. Senectus et netus et malesuada fames ac turpis.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:image {"aspectRatio":"1","scale":"cover","className":"is-style-rounded"} -->
<figure class="wp-block-image is-style-rounded"><img alt="" style="aspect-ratio:1;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size"></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cursus in hac habitasse platea dictumst quisque. Senectus et netus et malesuada fames ac turpis.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:image {"aspectRatio":"1","scale":"cover","className":"is-style-rounded"} -->
<figure class="wp-block-image is-style-rounded"><img alt="" style="aspect-ratio:1;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size"></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cursus in hac habitasse platea dictumst quisque. Senectus et netus et malesuada fames ac turpis.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->