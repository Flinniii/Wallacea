<?php
// phpcs:ignore
/**
 * Title: Query pagination.
 * Slug: icecubo/query-part-pagination-oval
 * Categories: hidden
 * Inserter: false
 */
?>
<!-- wp:group {"layout":{"inherit":false}} -->
<div class="wp-block-group"><!-- wp:query-pagination {"className":"is-style-icecubo-oval-post-byline"} -->
<!-- wp:query-pagination-previous /-->

<!-- wp:query-pagination-numbers /-->

<!-- wp:query-pagination-next /-->
<!-- /wp:query-pagination --></div>
<!-- /wp:group -->