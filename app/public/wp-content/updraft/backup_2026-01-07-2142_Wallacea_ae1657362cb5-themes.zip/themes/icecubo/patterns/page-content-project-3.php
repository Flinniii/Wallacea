<?php
// phpcs:ignore
/**
 * Title: Project page content (3).
 * Slug: icecubo/page-content-project-3
 * Categories: icecubo-page-project
 */
?>
<!-- wp:pattern {"slug":"icecubo/section-columns-project-info-3"} /-->

<!-- wp:spacer {"height":"150px"} -->
<div style="height:150px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/features-basic-heading-img-central-bordered"} /-->

<!-- wp:spacer {"height":"60px"} -->
<div style="height:60px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/features-basic-heading-img-central-bordered"} /-->