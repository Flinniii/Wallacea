<?php
// phpcs:ignore
/**
 * Title: Project page content (1).
 * Slug: icecubo/page-content-project-1
 * Categories: icecubo-page-project
 */
?>
<!-- wp:pattern {"slug":"icecubo/section-columns-project-info-1"} /-->

<!-- wp:spacer {"height":"150px"} -->
<div style="height:150px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/section-columns-feature-1large-img-2heading-list"} /-->

<!-- wp:spacer {"height":"150px"} -->
<div style="height:150px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/section-columns-feature-1large-img-2heading-list"} /-->
