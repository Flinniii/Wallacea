<?php
// phpcs:ignore
/**
 * Title: Project page content (2).
 * Slug: icecubo/page-content-project-2
 * Categories: icecubo-page-project
 */
?>
<!-- wp:pattern {"slug":"icecubo/section-columns-project-info-2"} /-->

<!-- wp:spacer {"height":"150px"} -->
<div style="height:150px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/features-columns-awesome-feature-sharp-bg"} /-->

<!-- wp:spacer {"height":"150px"} -->
<div style="height:150px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/features-columns-awesome-feature-sharp-bg"} /-->
