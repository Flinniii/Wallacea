<?php
// phpcs:ignore
/**
 * Title: Footer basic.
 * Slug: icecubo/post-footer-oval
 * Categories: hidden
 * Inserter: false
 */
?>
<!-- wp:group {"fontSize":"extra-small","style":{"spacing":{"blockGap":"0px"}}} -->
<div class="wp-block-group has-extra-small-font-size post-footer">
    <!-- wp:pattern {"slug":"icecubo/post-footer-inner-content"} /-->
</div>
<!-- /wp:group -->