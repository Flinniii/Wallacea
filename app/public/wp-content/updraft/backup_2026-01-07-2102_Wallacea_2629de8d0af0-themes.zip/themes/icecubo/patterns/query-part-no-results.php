<?php
// phpcs:ignore
/**
 * Title: No results on a query.
 * Slug: icecubo/query-part-no-results
 * Categories: hidden
 * Inserter: false
 */
?>
<!-- wp:query-no-results -->
<!-- wp:paragraph {"placeholder":"Add text or blocks that will display when a query returns no results."} -->
<p>No results.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->