<?php
// phpcs:ignore
/**
 * Title: Features outline in columns.
 * Slug: icecubo/features-basic-1st
 * Categories: icecubo-features
 */
?>
<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"style":{"spacing":{"blockGap":"var:preset|spacing|xx-small"}}} -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p><strong>Nunc egestas</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Nullam tincidunt adipiscing enim. Morbi nec metus.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"blockGap":"var:preset|spacing|xx-small"}}} -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p><strong>Nunc egestas</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Nullam tincidunt adipiscing enim. Morbi nec metus.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"blockGap":"var:preset|spacing|xx-small"}}} -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p><strong>Nunc egestas</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Nullam tincidunt adipiscing enim. Morbi nec metus.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->