<?php
// phpcs:ignore
/**
 * Title: Services page (1).
 * Slug: icecubo/page-services-1
 * Categories: icecubo-page-services
 */
?>
<!-- wp:pattern {"slug":"icecubo/hero-bg-img-inside-text"} /-->

<!-- wp:spacer {"height":"150px"} -->
<div style="height:150px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/section-columns-feature-1cover-2cta"} /-->

<!-- wp:spacer {"height":"150px"} -->
<div style="height:150px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/section-columns-feature-1cta-2cover"} /-->

 <!-- wp:spacer {"height":"150px"} -->
<div style="height:150px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/section-columns-feature-1cover-2cta"} /-->

<!-- wp:spacer {"height":"150px"} -->
<div style="height:150px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"icecubo/hero-bg-img-inside-box-testimonial"} /-->